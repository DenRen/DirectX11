#ifndef __DE_AUDIO_MANAGER_H
#define __DE_AUDIO_MANAGER_H

#include <al.h>
#include <alc.h>
#include <alu.h>
#include <alut.h>

#pragma comment(lib, "alut.lib")
#pragma comment(lib, "OpenAL32.lib")

//audio class
class deAudioManager
{
public:

};

#endif