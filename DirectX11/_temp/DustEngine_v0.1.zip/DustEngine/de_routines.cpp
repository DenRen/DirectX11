#include "de_routines.h"

//convert degrees to radians
double deg2rad(const double deg)
{
  return deg / 180 * DE_PI;
}